The logging configurations are defined in separate file "logback.xml"
specified in container.sh
(/goffish-2.6/gopher/code/modules/deployment/server/src/main/bin/container.sh)

JAVA_OPTS="-Dlogback.configurationFile=bin/logback.xml $JAVA_OPTS"

log level is specified in logback.xml :

 <logger name="SubGraphLogger" level="TRACE">
      <appender-ref ref="SG_FILE" />
  </logger>
  <logger name="PartitionLogger" level="TRACE">
      <appender-ref ref="PART_FILE" />
  </logger>
  <logger name="GraphLogger" level="TRACE">
      <appender-ref ref="GRAPH_FILE" />
  </logger>
  <root level="TRACE">
    <appender-ref ref="DEFAULT_FILE" />
  </root>

