import os
import json
import glob
import copy
from xml.etree.ElementTree import Element, SubElement, Comment, tostring
#from ElementTree_pretty import prettify

'''
 * changes necessary script files in goffish deployment depending on the json files in gofs-config
 *
 *
 * @author Neel Choudhury
 * @version 1.0
 * @see <a href="http://www.dream-lab.in/">DREAM:Lab</a>
 *
 * Copyright 2014 DREAM:Lab, Indian Institute of Science, 2014
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.

 '''



def get_file_name_match(filepattern, folder_path):
	file_path = folder_path + "/" + filepattern
	return glob.glob(file_path)[0]

def gen_list_xml(graph_data):
	goffish_root = os.environ.get('GOFFISH_ROOT')
	folder_path = goffish_root + "/deployment/samples/gofs-samples/graphs/" + graph_data["graph_folder"]
	root = Element('gml')
	#root.append(etree.Element('template'))
	#root.append(etree.Element('instances'))
	template_child = SubElement(root,'template')
	template_child.text = get_file_name_match("*template*", folder_path)
	

	instaces_child = SubElement(root,'instances')

	for i in range(1, int(graph_data["number_of_instance"])+1):
		i_child = SubElement(instaces_child,'instance')
		i_child.text = get_file_name_match("*instance-" + str(i)+ "*",folder_path)

	print tostring(root)
	return tostring(root)
	

def gen_gofs_config(instance_list):
	gofs_config_data = ""
	gofs_config_data = gofs_config_data + "# Config File for formatting a GoFS cluster\n"
	gofs_config_data = gofs_config_data + "# -----------------------------------------\n"
	gofs_config_data = gofs_config_data + "# the name node uri\n"
	gofs_config_data = gofs_config_data + "gofs.namenode.type = edu.usc.goffish.gofs.namenode.RemoteNameNode\n"
	gofs_config_data = gofs_config_data + "gofs.namenode.location = http://" + instance_list["namenode"]["public_dns"] +":9998\n"
	gofs_config_data = gofs_config_data + "# list of data nodes to format and add to the name node\n"
	gofs_config_data = gofs_config_data + "# repeat for each data node to include\n"


	for inst in instance_list["list_of_instances"]:
		goffish_home = os.environ.get('GOFFISH_HOME')
		filepath = "file://" + inst["public_dns"] + goffish_home + ""
		gofs_config_data = gofs_config_data + "gofs.datanode =" + filepath + "/gofs-data/\n" 
	gofs_config_data = gofs_config_data + "# full class name of the serializer to use at every data node\n\n"
	gofs_config_data = gofs_config_data + "# gofs.serializer = edu.usc.goffish.gofs.slice.JavaSliceSerializer\n"
	gofs_config_data = gofs_config_data + "gofs.serializer = edu.usc.goffish.gofs.slice.KryoSliceSerializer\n"
	print gofs_config_data
	return gofs_config_data



def gen_setup_gopher(instance_list, jar_data):
	goffish_home = os.environ.get('GOFFISH_HOME')
	goffish_root = os.environ.get('GOFFISH_ROOT')
	print goffish_root

	script_root = goffish_root + "/deployment/gopher-client-2.0/bin"

	jar_path = goffish_root + "/deployment/samples/gopher-jars/" + jar_data["jar_name"]
	config_path = goffish_home + "/gofs-2.0/conf/gofs.config"

	#copy artifacts
	setup_gopher_string = ""
	setup_gopher_string = setup_gopher_string +  script_root +"/CopyArtifacts.sh " + jar_path + " " +  jar_data["jar_name"] + " ${USER} "
	for inst in instance_list["list_of_instances"]:
		setup_gopher_string = setup_gopher_string + " " + inst["public_dns"]
	setup_gopher_string = setup_gopher_string + "\n\n"

	#start server

	setup_gopher_string = setup_gopher_string +  script_root + "/StartServers.sh ${USER} " + instance_list["namenode"]["public_dns"] + " " + instance_list["namenode"]["public_dns"] + " "
	setup_gopher_string =  setup_gopher_string + jar_data["graph_id"] + " "

	for inst in instance_list["list_of_instances"]:
		goffish_home = os.environ.get('GOFFISH_HOME')
		filepath = "file://" + inst["public_dns"] +  goffish_home + "/"
		setup_gopher_string = setup_gopher_string +  filepath + "gofs-data/gofs " 

	setup_gopher_string = setup_gopher_string + "\n\nsleep 5s;\n\n"

	#deploy gopher
	setup_gopher_string = setup_gopher_string + script_root +"/DeployGopher.sh " + config_path + " "+ instance_list["namenode"]["public_dns"] + " " + instance_list["namenode"]["public_dns"]
	setup_gopher_string = setup_gopher_string + "\n\n"



	print setup_gopher_string
	return setup_gopher_string

#/GoFSDeployGraph edu.usc.goffish.gofs.namenode.RemoteNameNode 
#http://ec2-54-179-155-131.ap-southeast-1.compute.amazonaws.com:9998 "fbgraph3" 2 /home/ec2-user/goffish/deployment/samples/gofs-samples/list.xml
def gen_run_gofs_deploy(instance_list, graph_data):
	goffish_root = os.environ.get('GOFFISH_ROOT')


	run_gofs_string = ""
	run_gofs_string = run_gofs_string + "./GoFSDeployGraph edu.usc.goffish.gofs.namenode.RemoteNameNode "
	run_gofs_string = run_gofs_string + "http://" + instance_list["namenode"]["public_dns"]+ ':9998 "' + graph_data["graph_id"]+ '" '
	run_gofs_string = run_gofs_string + str(len(instance_list["list_of_instances"])) + " "
	run_gofs_string = run_gofs_string + goffish_root + "/deployment/samples/gofs-samples/list.xml"
	print run_gofs_string
	return run_gofs_string



#./GopherClient.sh /home/ec2-user/goffish/deployment/gopher-client-2.0/gopher-config.xml 
#/home/ec2-user/goffish/deployment/goffish_home/gofs-2.0/conf/gofs.config fbgraph3 vert-count-2.0.jar edu.usc.pgroup.goffish.gopher.sample.VertCounter NILL
def gen_run_gopher_client(jar_data):
	goffish_root = os.environ.get('GOFFISH_ROOT')
	goffish_home = os.environ.get('GOFFISH_HOME')

	run_gopher_string = ""
	run_gopher_string = run_gopher_string + "./GopherClient.sh "
	run_gopher_string = run_gopher_string + goffish_root + "/deployment/gopher-client-2.0/gopher-config.xml "
	run_gopher_string = run_gopher_string + goffish_home + "/gofs-2.0/conf/gofs.config "
	run_gopher_string = run_gopher_string + jar_data["graph_id"] + " "
	run_gopher_string = run_gopher_string + jar_data["jar_name"] + " "
	run_gopher_string = run_gopher_string + jar_data["class_path"] + " "
	run_gopher_string = run_gopher_string + jar_data["araguments"] + " "

	if int(jar_data["iterations"]) != 0:
		run_gopher_string = run_gopher_string + jar_data["iteration"] + " "

	print run_gopher_string
	return run_gopher_string


def gen_kill_gopher(instance_list):
	goffish_root = os.environ.get('GOFFISH_ROOT')
	goffish_home = os.environ.get('GOFFISH_HOME')

	kill_gopher_script = ""
	kill_command = "kill $(ps aux | grep -v [N]ameNode | grep '[l]ocalhost' | awk '{print $2}')\n"
	if(instance_list["list_of_instances"][0]["public_dns"] == "localhost"):
		kill_gopher_script = kill_gopher_script + kill_command
	else:
		for inst in instance_list["list_of_instances"]:
			kill_gopher_script = kill_gopher_script + "ssh ec2-user@" + inst["public_dns"] + ' "' + kill_command + '"'

	print kill_gopher_script
	return kill_gopher_script

def gen_start_namenode(instance_list):
	goffish_home = os.environ.get('GOFFISH_HOME')
	dns = instance_list["namenode"]["public_dns"]
	start_namenode_str = ""
	start_namenode_str = start_namenode_str + goffish_home + "/gofs-2.0/bin/GoFSNameNode "
	start_namenode_str = start_namenode_str + "http://" + dns + ":9998 "
	start_namenode_str = start_namenode_str + " namenode.txt"

	return start_namenode_str


def read_json(filename):
	f = open(filename, 'r')
	fstr = "".join(f.read().split())
	fdir =  json.loads(fstr)
	return fdir
	f.close()


def write_file(filename,string):
	f = open(filename, 'w')
	f.write(string)
	f.close()


if __name__ == "__main__":
	goffish_root = os.environ.get('GOFFISH_ROOT')
	goffish_home = os.environ.get('GOFFISH_HOME')

	instance_list = read_json( goffish_root + "/deployment/goffish_conf/instance_list.json")
	jar_data = read_json(goffish_root + "/deployment/goffish_conf/jar_data.json")
	graph_data = read_json(goffish_root +  "/deployment/goffish_conf/graph_data.json")
	print jar_data
	#gen_gofs_config(instance_list)

	#gen_setup_gopher(instance_list, jar_data)
	

	write_file( goffish_home + "/gofs-2.0/conf/gofs.config" ,gen_gofs_config(instance_list))
	
	write_file(goffish_home + "/gofs-2.0/bin/StartNamenode.sh", gen_start_namenode(instance_list))
	os.system("chmod 777 " + goffish_home + "/gofs-2.0/bin/StartNamenode.sh")

	write_file( goffish_home + "/gofs-2.0/bin/RunGoFSDeploy.sh",gen_run_gofs_deploy(instance_list, graph_data))
	os.system("chmod 777 " + goffish_home + "/gofs-2.0/bin/RunGoFSDeploy.sh")
	
	write_file( goffish_root + "/deployment/samples/gofs-samples/list.xml",gen_list_xml(graph_data))

	write_file( goffish_root + "/deployment/gopher-client-2.0/bin/setup-gopher.sh",gen_setup_gopher(instance_list, jar_data))
	os.system("chmod 777 " + goffish_root + "/deployment/gopher-client-2.0/bin/setup-gopher.sh")

	write_file( goffish_root + "/deployment/gopher-client-2.0/bin/RunGopherClient.sh",gen_run_gopher_client(jar_data))
	os.system("chmod 777 " + goffish_root + "/deployment/gopher-client-2.0/bin/RunGopherClient.sh")

	write_file( goffish_root + "/deployment/gopher-client-2.0/bin/KillGopher.sh",gen_kill_gopher(instance_list))
	os.system("chmod 777 " + goffish_root + "/deployment/gopher-client-2.0/bin/KillGopher.sh")

