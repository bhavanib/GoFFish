#!/bin/bash


./CopyArtifacts.sh /Users/neel/IISc/project/Softwares/goffish_final/deployment/samples/vert-count-2.0.jar vert-count-2.0.jar ${USER} localhost

./StartServers.sh ${USER} localhost localhost "fbgraph" file://localhost/Users/neel/IISc/project/Softwares/goffish_final/deployment/goffish_home/gofs-data/gofs

sleep 5s;

./DeployGopher.sh /Users/neel/IISc/project/Softwares/goffish_final/deployment/goffish_home/gofs-2.0/conf/gofs.config localhost localhost
