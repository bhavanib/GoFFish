cd ~

sudo apt-get update

sudo apt-get install openjdk-7-jdk
export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-amd64
echo 'export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-amd64 ' >>~/.bashrc
export PATH=$JAVA_HOME:$PATH
echo 'export PATH=$JAVA_HOME:$PATH' >>~/.bashrc

source ~/.bashrc

sudo apt-get install maven
sudo apt-get install unzip
sudo apt-get install openssh-server

wget http://glaros.dtc.umn.edu/gkhome/fetch/sw/metis/metis-5.1.0.tar.gz
tar -xzvf metis-5.1.0.tar.gz
pushd metis-5.1.0
sudo apt-get install cmake
sudo apt-get install gcc g++
make config
make
sudo make install

popd #back to root

mkdir goffish
pushd goffish

wget https://github.com/usc-cloud/floe/archive/gh-pages.zip
unzip gh-pages.zip
pushd floe-gh-pages/source/framework
cp modules/azure-plugin/src/main/java/org/soyatec/windowsazure/blob/IBlobContainer.java  modules/azure-plugin/src/main/java/org/soyatec/windowsazure/blob/IBlobContainer1.java 
sed '481d' modules/azure-plugin/src/main/java/org/soyatec/windowsazure/blob/IBlobContainer1.java > modules/azure-plugin/src/main/java/org/soyatec/windowsazure/blob/IBlobContainer.java
rm modules/azure-plugin/src/main/java/org/soyatec/windowsazure/blob/IBlobContainer1.java
mvn install

popd
rm gh-pages.zip

#download and compile goffish
wget https://github.com/usc-cloud/goffish/archive/master.zip
unzip master.zip
pushd goffish-master/goffish-trunk/
mvn install

popd
rm master.zip
