# Add your deployment scripts here:

export SCRIPT_HOME=`pwd`
sudo bash $SCRIPT_HOME/install.sh
#source ~/.bashrc
#sudo bash $SCRIPT_HOME/deploy.sh
#source ~/.bashrc
#sudo bash $SCRIPT_HOME/security.sh