cp ~/scripts/pem/id_rsa ~/.ssh
cp ~/scripts/pem/id_rsa.pub ~/.ssh
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys