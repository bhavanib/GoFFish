cd ~
pushd goffish #to be removed

export GOFFISH_ROOT=`pwd`
echo 'export GOFFISH_ROOT='`pwd` >>~/.bashrc

mkdir deployment
pushd deployment

mkdir goffish_home
pushd goffish_home
export GOFFISH_HOME=`pwd`
echo 'export GOFFISH_HOME='`pwd` >>~/.bashrc

mkdir gofs-data
cp ../../goffish-master/goffish-trunk/gofs/code/modules/gofs-distribution/target/gofs-2.0-bin.zip .
unzip gofs-2.0-bin.zip
rm gofs-2.0-bin.zip
pushd gofs-2.0/bin
chmod a+rx GoFS*
cp ~/scripts/conf/gofs.config ../conf/gofs.config

popd #back to goffish home

cp ../../goffish-master/goffish-trunk/gopher/code/modules/deployment/server/target/gopher-server-2.0-bin.zip .
unzip gopher-server-2.0-bin.zip
rm gopher-server-2.0-bin.zip

popd #back to deployment

cp ../goffish-master/goffish-trunk/gopher/code/modules/deployment/client/target/gopher-client-2.0-bin.zip .
unzip gopher-client-2.0-bin.zip
rm gopher-client-2.0-bin.zip

mkdir samples
pushd samples

#copy sample graph
cp -r ../../goffish-master/goffish-trunk/gofs/code/modules/gofs-distribution/sample-applications/ ./gofs-samples
#add few more graphs
pushd gofs-samples
mkdir graphs

cp -r ~/scripts/graphs/* ./graphs/

popd #back to samples


mkdir gopher-jars
pushd gopher-jars

#copy all sample application
cp ../../../goffish-master/goffish-trunk/gopher/samples/vertex-count/target/vert-count-2.0.jar .
cp ../../../goffish-master/goffish-trunk/gopher/samples/connected-components/target/connected-components-1.0.jar .
cp ../../../goffish-master/goffish-trunk/gopher/samples/page-rank/target/page-rank-1.0.jar .
cp ../../../goffish-master/goffish-trunk/gopher/samples/shortest-path//target/shortest-path-1.0.jar .

popd #back to samples
cp ~/scripts/conf/list.xml ./gofs-samples/list.xml

popd #back to deployment

pushd gopher-client-2.0/bin

cp ~/scripts/gopher-client/* .

popd #back to deployment

mkdir goffish_conf
pushd goffish_conf

cp ~/scripts/goffish_conf/* .



popd #back to goffish root

python ~/goffish/deployment/goffish_conf/gen_gofs_configs.py
